<?php

    $host = "localhost";
    $user = "root";
    $password = "";
    $db = "logindb";

    $connect = mysqli_connect($host, $user, $password, $db);

    if(isset($_POST['user']))
    {
        $username = $_POST['user'];
        $password = $_POST['pass'];

        $sql = "select * from table_users where username='".$username."' && password='".$password."' limit 1";

        $result = mysqli_query($connect, $sql);

        $row = mysqli_fetch_array($result);

        if($row['username'] == $username && $row['password'] == $password)
        {
            echo "Login successful! Welcome " . $row['username'];
        }
        else
        {
            echo "Failed to Login!";
        }
    }
?>